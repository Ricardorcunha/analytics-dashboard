# TechStore Analytics Dashboard 📊

Dashboard executivo premium para análise de vendas da TechStore Brasil com design moderno, interativo e totalmente responsivo.

## 🎯 Características Principais

### 📈 Visualizações de Dados
- **Evolução de Receita vs Lucro** - Gráfico de linha dual axis com tendências
- **Receita por Categoria** - Donut chart interativo (clique para filtrar)
- **Receita por Canal** - Barras horizontais mostrando performance
- **Receita por Região** - Análise geográfica com dados em tempo real
- **Formas de Pagamento** - Distribuição equilibrada de métodos
- **Evolução da Margem de Lucro** - Tendência de lucratividade

### 🎛️ Funcionalidades Avançadas
- ✅ **Filtro de Período** - 6 meses, 12 meses ou tudo
- ✅ **Comparador de Períodos** - Compare 2 períodos lado a lado
- ✅ **Exportar Relatórios** - PDF, CSV ou JSON
- ✅ **Filtro por Categoria** - Clique em categoria para filtrar todos os gráficos
- ✅ **KPIs em Tempo Real** - Receita, Lucro, Margem, Períodos
- ✅ **Top Produtos & Vendedores** - Ranking com métricas

### 📱 Design & UX
- **Dark Mode Vibrante** - Verde neon (#1DE9B6) + Roxo (#DA70D6)
- **Totalmente Responsivo** - Mobile, Tablet, Desktop
- **Animações Suaves** - Transições de 300ms com easing natural
- **Eixos em Mês/Ano** - Formato claro (Jan/24, Fev/24...)
- **Glassmorphism Moderno** - Efeitos visuais premium

## 📊 Dados Inclusos

- **18 períodos mensais** (Nov 2024 - Abr 2026)
- **6 categorias de produtos** (Notebooks, Smartphones, Monitores, etc)
- **6 canais de venda** (Site, Marketplace, Loja Física, App, WhatsApp, B2B)
- **5 regiões** (Sudeste, Sul, Nordeste, Centro-Oeste, Norte)
- **5 formas de pagamento** (Boleto, Transferência, PIX, Cartão)
- **10 top produtos** com quantidade e receita
- **5 top vendedores** com métricas de performance

## 🚀 Como Usar

### Opção 1: Abrir Direto
```bash
# Clone o repositório
git clone https://github.com/seu-usuario/techstore-analytics.git

# Abra o arquivo no navegador
open index.html
# ou
google-chrome index.html
```

### Opção 2: Servir Localmente (Recomendado)
```bash
# Com Python 3
python3 -m http.server 8000

# Com Node.js
npx http-server

# Acesse: http://localhost:8000
```

## 📋 Estrutura do Projeto

```
techstore-analytics/
├── index.html                 # Dashboard principal
├── README.md                  # Este arquivo
├── LICENSE                    # Licença MIT
├── .gitignore                 # Arquivos ignorados pelo Git
├── docs/
│   ├── FEATURES.md           # Descrição detalhada de funcionalidades
│   ├── DATA_STRUCTURE.md     # Estrutura dos dados
│   ├── DEPLOYMENT.md         # Como fazer deploy
│   └── CONTRIBUTING.md       # Guia de contribuição
├── assets/
│   ├── images/               # Screenshots e demos
│   └── demo-data.json        # Exemplo de dados para integração
└── examples/
    └── api-integration.html  # Exemplo de integração com API
```

## 🎨 Paleta de Cores

```css
--bg-primary: #0A0E27          /* Background principal */
--bg-secondary: #0F1429        /* Cards e superfícies */
--color-green: #1DE9B6         /* Verde neon (primária) */
--color-purple: #DA70D6        /* Roxo vibrante (destaque) */
--color-blue: #40E0D0          /* Cyan (secundária) */
--color-orange: #FFD54F        /* Laranja (alertas) */
```

## 📊 Filtros e Funcionalidades

### Filtro de Período
- **6m** - Últimos 6 meses
- **12m** - Últimos 12 meses
- **Tudo** - Todos os dados disponíveis

### Comparador de Períodos
Compara KPIs entre 2 períodos diferentes mostrando:
- Diferença de Receita (R$ e %)
- Diferença de Lucro (R$ e %)
- Diferença de Margem (pp)

### Exportar Relatório
- **PDF** - Relatório visual completo com gráficos
- **CSV** - Dados estruturados para Excel/Sheets
- **JSON** - Dados brutos para APIs/sistemas

## 💻 Tecnologias Utilizadas

- **HTML5** - Estrutura semântica
- **CSS3** - Grid, Flexbox, Gradientes
- **JavaScript (Vanilla)** - Zero dependências
- **Chart.js 4.4.1** - Gráficos responsivos
- **html2pdf.js** - Exportar para PDF

## 📱 Responsividade

| Breakpoint | Dispositivo | Grid |
|-----------|-----------|------|
| > 1200px | Desktop | 2-3 colunas |
| 768px - 1200px | Tablet | 1-2 colunas |
| < 768px | Mobile | 1-2 colunas |
| < 480px | Mobile S | 1 coluna |

## 🔄 Como Integrar Dados Reais

1. **Substitua o objeto `data`** no arquivo HTML com dados de sua API
2. **Use o endpoint**:
   ```javascript
   fetch('/api/dashboard-data')
     .then(r => r.json())
     .then(data => {
       // Atualizar gráficos
     })
   ```
3. **Ou importe dados externos**:
   ```javascript
   import data from './data.json'
   ```

Veja `examples/api-integration.html` para exemplo completo.

## 📈 Métricas Incluídas

### KPIs Principais
- Receita Total
- Lucro Total
- Margem de Lucro (%)
- Ticket Médio
- Total de Pedidos
- Crescimento vs Período Anterior

### Análises
- Evolução temporal de receita e lucro
- Distribuição por categoria
- Performance por canal
- Cobertura regional
- Métodos de pagamento
- Top produtos por receita/quantidade
- Top vendedores por receita

## 🎯 Casos de Uso

✅ **Executivos** - Visão geral de negócio em tempo real
✅ **Gestores de Vendas** - Análise por canal, região e vendedor
✅ **Analistas de Dados** - Exportar dados para análise detalhada
✅ **Empreendedores** - Dashboard pessoal de e-commerce
✅ **Consultorias** - Apresentação para clientes

## 🛠️ Customização

### Mudar Paleta de Cores
Edite as variáveis CSS no `:root`:
```css
:root {
    --color-green: #1DE9B6;
    --color-purple: #DA70D6;
    /* ... */
}
```

### Alterar Período Padrão
Na função `filterPeriod()`, mude:
```javascript
currentPeriod = '12m'; // altere de '6m'
```

### Adicionar Novas Categorias
No objeto `data.categoria`, adicione:
```javascript
categoria: {
    Notebooks: 48152623.34,
    "Nova Categoria": 10000000.00,
    // ...
}
```

## 📄 Licença

MIT License - Veja arquivo [LICENSE](LICENSE) para detalhes.

## 👥 Contribuindo

Contribuições são bem-vindas! Por favor:
1. Faça um Fork
2. Crie uma branch (`git checkout -b feature/melhoria`)
3. Commit suas mudanças (`git commit -m 'Add feature'`)
4. Push para a branch (`git push origin feature/melhoria`)
5. Abra um Pull Request

Veja [CONTRIBUTING.md](docs/CONTRIBUTING.md) para mais detalhes.

## 🐛 Reportar Bugs

Abra uma [Issue](https://github.com/seu-usuario/techstore-analytics/issues) com:
- Descrição clara do problema
- Passos para reproduzir
- Navegador e versão
- Screenshots se aplicável

## ⭐ Suportar o Projeto

Se esse projeto foi útil, deixe uma ⭐ no GitHub!

## 📞 Contato

Para dúvidas ou sugestões:
- Abra uma [Discussion](https://github.com/seu-usuario/techstore-analytics/discussions)
- Envie um email para seu-email@exemplo.com

## 🚀 Roadmap

- [ ] Tema claro (Light Mode)
- [ ] Integração com APIs reais
- [ ] Alertas automáticos
- [ ] Exportar para PowerPoint
- [ ] Gráfico de previsão (Forecasting)
- [ ] Modo offline (PWA)
- [ ] Painel de configurações
- [ ] Multi-idioma

## 📚 Recursos

- [Chart.js Documentação](https://www.chartjs.org/)
- [HTML2PDF Documentação](https://ekoopmans.github.io/html2pdf.js/)
- [CSS Grid Guide](https://css-tricks.com/snippets/css/complete-guide-grid/)
- [Responsive Design](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)

---

**Desenvolvido com ❤️ para análise de dados em tempo real**

Última atualização: 20 de maio de 2026
