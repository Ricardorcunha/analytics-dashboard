# 📊 Estrutura de Dados

## Objeto Principal `data`

```javascript
const data = {
  evolucao: Array,
  categoria: Object,
  canal: Object,
  regiao: Object,
  pagamento: Object,
  produtos: Array,
  vendedores: Array
}
```

## Evolução (Série Temporal)

```javascript
evolucao: [
  {
    periodo: "2024-11",      // YYYY-MM
    receita: 6652462.45,     // R$ em centavos
    lucro: 1634283.46        // R$ em centavos
  },
  // ... 17 períodos mais
]
```

- **18 períodos** (Nov 2024 - Abr 2026)
- Receita média: ~R$ 7M
- Lucro médio: ~R$ 1.7M
- Margem consistente: ~24%

## Categorias

```javascript
categoria: {
  "Notebooks": 48152623.34,
  "Smartphones": 35826883.16,
  "Monitores": 14643759.20,
  "Áudio e TV": 11988442.52,
  "Componentes": 11421410.52,
  "Acessórios": 2801516.75
}
```

- **6 categorias**
- Notebooks: 38.5% (líderes)
- Smartphones: 28.7% (segundos)
- Outros 4: ~33% distribuído
- **Total**: R$ 124.8B

## Canais

```javascript
canal: {
  "Site": 44138161.58,
  "Marketplace": 29738625.17,
  "Loja Física": 22670886.09,
  "App": 14573644.82,
  "WhatsApp": 9071370.40,
  "B2B": 4641947.43
}
```

- **6 canais**
- Site: 35.3% (maior)
- Marketplace: 23.8%
- Loja Física: 18.2%
- App: 11.7%
- WhatsApp: 7.3%
- B2B: 3.7%
- **Total**: R$ 124.8B

## Regiões

```javascript
regiao: {
  "Sudeste": 57333429.46,
  "Sul": 22544193.14,
  "Nordeste": 21369555.22,
  "Centro-Oeste": 13638701.46,
  "Norte": 9948756.21
}
```

- **5 regiões**
- Sudeste: 45.9% (dominante)
- Sul: 18.0%
- Nordeste: 17.1%
- Centro-Oeste: 10.9%
- Norte: 7.9%
- **Total**: R$ 124.8B

## Pagamento

```javascript
pagamento: {
  "Boleto": 25449653.32,
  "Transferência": 25365343.22,
  "Pix": 24995874.21,
  "Cartão de crédito": 24989454.10,
  "Cartão de débito": 24034310.64
}
```

- **5 métodos**
- Distribuição equilibrada (~20% cada)
- Boleto: 20.4% (ligeira liderança)
- PIX: 20.0% (em crescimento)
- **Total**: R$ 124.8B

## Produtos

```javascript
produtos: [
  {
    nome: "MacBook Air M2",
    quantidade: 2523,
    receita: 18019430.36
  },
  // ... 9 produtos mais
]
```

- **10 top produtos**
- Ranking por quantidade
- Receita total calculada
- **Exemplos**:
  - MacBook: 2.523 unidades / R$ 18M
  - iPhone 15: 2.549 unidades / R$ 14.9M
  - Produtos em falta: 1-10M cada

## Vendedores

```javascript
vendedores: [
  {
    nome: "Isabela Nunes",
    receita: 10916121.27
  },
  // ... 4 vendedores mais
]
```

- **5 top vendedores**
- Ranking por receita
- Distribuição homogênea
- Cada um: ~R$ 10.5M-10.9M

## Relacionamentos

### Hierarquia de Dados
```
Período
├── Receita (global)
├── Lucro (global)
└── Margem derivada

Categoria → Produtos
├── 6 categorias
└── ~10 produtos top

Canal → Transações
├── 6 canais
└── Cada com múltiplas regiões

Região → Vendedores
├── 5 regiões
└── 5 vendedores main

Método Pagamento → Transações
├── 5 métodos
└── Distribuição ~20% cada
```

### Cálculos Derivados

```javascript
// Margem por período
margem = (lucro / receita) * 100

// Ticket médio
ticketMedio = receita / quantidadeTransacoes

// Custo por período
custo = receita - lucro

// Crescimento vs período anterior
crescimento = ((atual - anterior) / anterior) * 100
```

## Volume e Distribuição

| Métrica | Valor | Nota |
|---------|-------|------|
| Períodos | 18 | 6 meses até 18 meses |
| Receita Total | R$ 124,8B | ~R$ 6,9B/mês |
| Lucro Total | R$ 30,2B | ~R$ 1,7B/mês |
| Margem Média | 24.2% | Consistente |
| Transações | 32.000 | Estimado |
| Ticket Médio | R$ 3.901 | Receita / Transações |
| Categorias | 6 | Produtos principais |
| Canais | 6 | Pontos de venda |
| Regiões | 5 | Cobertura geográfica |
| Métodos Pagamento | 5 | Opções de checkout |
| Produtos | 10 | Top sellers |
| Vendedores | 5 | Performance ranking |

## Formato de Valores

### Monetário
- Armazenado: Centavos (6652462.45 = R$ 6.652.462,45)
- Exibido: Formatado com separadores
  - `fmt.currency()` → R$ 6.652.462
  - CSV export → 6652462.45
  - PDF → R$ 6,6M

### Percentual
- Armazenado: Decimal (24.2)
- Exibido: Com símbolo (24.2%)
- Cálculo: (valor / total) * 100

### Temporal
- Armazenado: "2024-11" (YYYY-MM)
- Exibido: "Nov/24" (Mês/Ano)
- Ordenação: Cronológica

## Integração de Dados Reais

Para substituir por API real:

```javascript
// Opção 1: Fetch dinâmico
async function loadData() {
  const response = await fetch('/api/dashboard');
  const data = await response.json();
  return data;
}

// Opção 2: Import de arquivo
import data from './data.json';

// Opção 3: WebSocket para tempo real
const ws = new WebSocket('wss://api.example.com/data');
ws.onmessage = (e) => {
  const newData = JSON.parse(e.data);
  updateDashboard(newData);
};
```

## Validação de Dados

```javascript
// Verificar integridade
function validateData(data) {
  // Verificar campos obrigatórios
  if (!data.evolucao || !data.categoria) return false;
  
  // Verificar tipos
  if (!Array.isArray(data.evolucao)) return false;
  if (typeof data.categoria !== 'object') return false;
  
  // Verificar valores
  const totalReceita = Object.values(data.categoria)
    .reduce((a,b) => a+b, 0);
  if (totalReceita <= 0) return false;
  
  return true;
}
```

## Performance

- **Tamanho JSON**: ~3KB (sem compressão)
- **Tamanho HTML**: ~250KB (com lógica inline)
- **Carregamento**: < 500ms
- **Renderização**: < 1s (todos os gráficos)

---

Última atualização: 20 de maio de 2026
